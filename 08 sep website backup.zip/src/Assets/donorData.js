export const individualDonor = [
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    // ... add other individual donors here as needed
];
export const individualDonors = [
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Dr. Shamsher Prakash",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.23 crores (22.3 Million INR) for",
            "1.) Shamsher Prakash Chair Professor, and",
            "2.) Shamsher Prakash Technology Award in the field of Soil Dynamics at IITR.",
            "US based IITR Alumnus – B.E. Civil Engineering, 1954. Distinguished Member ASCE, Founder of SP foundation, Conduct Yoga classes worldwide."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    {
        title: "Mr. Mohinder L. Nayyar",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 2.89 crores (28.9 Million INR) for the following Awards:",
            "Nayyar Award for Excellence in Communication",
            "Suri Awards for Excellence in Sports & Extracurricular Activities",
            "Prabha Nayyar Award for Excellence in Time Management",
            "Sir Ganga Ram Awards for Excellence in Research & Development",
            "Smt. Lilawati Nayyar Golden Jubilee Scholarship",
            "US based IITR Alumnus – B.E. Mechanical Engineering, 1966; Registered professional engineer, Virginia."
        ]
    },
    // ... add other individual donors here as needed
];

export const batchDonor = [
    {
        title: "1999 Batch (Including B.Arch 2000) (Pledge Rs. 5.05 Crore)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1999 batch Pledge Rs. 5.05 Crore (50.5 Million INR) during their Silver Jubilee Reunion held in 2024."
        ]
    },
    {
        title: "Class gift by 1998 Batch (Rs. 1.32 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1998 batch donated Rs. 1.32 Crore (13.2 Million INR) during their Silver Jubilee Reunion held in 2023 for the 16 scholarships."
        ]
    },
    // ... add more batch donors
];
export const batchDonors = [
    {
        title: "1999 Batch (Including B.Arch 2000) (Pledge Rs. 5.05 Crore)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1999 batch Pledge Rs. 5.05 Crore (50.5 Million INR) during their Silver Jubilee Reunion held in 2024."
        ]
    },
    {
        title: "1994 - Batch (Rs. 1.57 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1994 batch donated Rs. 1.57 Crore (15.74 Million INR) during their Silver Jubilee Reunion held in November 2019 for the following purposes:",
            "Ten Merit Cum Means Scholarships to support 10 students @ Rs. 10,000 per year perpetually.",
            "Two Research Fellowship for mid-career Faculty for six years.",
            "Centre of Excellence for Drone Research (CEDR) to evolve as a unique facility at national level where state of the art and frontier research would be conducted on several aspects of Drone technology and its applications."
        ]
    },
    {
        title: "Class gift by 1998 Batch (Rs. 1.32 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1998 batch donated Rs. 1.32 Crore (13.2 Million INR) during their Silver Jubilee Reunion held in 2023 for the 16 scholarships."
        ]
    },
    {
        title: "Class gift by 1996 Batch (Rs. 1.31 Crore)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1996 batch donated Rs. 1.31 Crore (13.1 Million INR) during their Silver Jubilee Reunion held in 2022 ."
        ]
    },
    {
        title: "Class gift by 1989 Batch (Rs. 1.14 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Established a corpus, Eighty Nine Class of Roorkee Endowment (Encore) of Rs. 1.14 Crore (11.42 Million INR) by alumni of 1989- Batch to Support the following schemes:",
            "Two or more ENCORE All-Round Excellence Awards of Rs 60,000 (or more) each for 4th year students with a minimum of one award for girl students.",
            "Six or more ENCORE Merit-cum-Means Awards of Rs 30,000 (or more) each for 3rd year students with a minimum of two awards for girl students.",
            "Six or more ENCORE Merit-cum-Means Awards of Rs 30,000 (or more) each for 2nd year students with a minimum of two awards for girl students.",
            "ENCORE IITR Lecture Series - To fund the travel and any other expenses of well recognized experts to the Institute for giving a talk and interacting with the faculty and students - Rs. 4.10 Lac (which covers expenses for 10 years).",
            "ENCORE Technical Projects Award - To fund interesting and big team projects on the campus, like building a racing car, robot, autonomous vehicle etc. which can compete at national/international competitions – Rs 16.25 Lac (which covers expenses for 10 years)",
        ]
    },
    {
        title: "Class gift by 1992 Batch (Rs. 1.12 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1992 batch made a class gift of Rs. 1.12 Crore (11.2 Million INR) during their Silver jubilee Reunion held in November 2017 for the following purpose:",
            "One James Thomason Scholarship @ Rs. 25,000/- per month for a JEE entrant with All India Rank up to 300. This would be known as “James Thomason Scholarship (Sponsored by 92 Batch)”.",
            "Five Merit Cum Means Scholarships to deserving students @ Rs. 1000 per month. The scholarship would be known as “92 Batch Student Scholarship (92BSS)”.",
            "One Chair Professorship for faculty, which would be known as “92 Batch Chair Professor (92BCP)”, for the period of six years.",
        ]
    },
    {
        title: "Class gift by 1997 Batch (Rs. 1.14 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1997 batch donated Rs. 1.14 Crore (11.4 Million INR) during their Silver Jubilee Reunion held in 2022 for the following purposes:",
            "Sesquicentennial (1997) Batch Scholarships for academic excellence",
            "Sesquicentennial (1997) Batch Silver Jubilee Award for excellence in sports",
            "Research Fellowships for Mid-Career Faculty",
            "Donation for Anushruti Academy for the Deaf",
            "Support for Student's Technical Projects"
        ]
    },
    {
        title: "1981 Batch (Including B.Arch 1982) (Pledge Rs. 1.03 Crore)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1981 batch donated Rs. 1.03 Crore (10.3 Million INR) during their Ruby Jubilee Reunion held in 2023 for the following purposes:",
            "Anushruti Academy for Deaf (Under CSR)",
            "Bridgecon Lab",
            "Metaverse Zone - Supported by 1981 Batch",
            "Anushruti Academy for the Deaf",
            "ASMITA for Women",
        ]
    },
    {
        title: "Class gift by 1993 Batch (Rs. 84.10 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1993 batch donated Rs. 84.10 Lac during their Silver Jubilee Reunion to to support the following schemes:",
            "Leadership Lecture Series: INR 12.50 L: For providing a forum for the senior executives from the public and private sectors, Influential leaders and policymakers to address pertinent leadership issues and share their insights with students and to fund the domestic travel and local hospitality of well recognised experts to the lnstitute for giving a talk and interacting with the faculty and students of IITR along with bringing Expertise ranging from business and philanthropy to public service and academic research to the students",
            "TIDES Initiation Grant: INR 19.86 L : Support/facilitate TIDES initiative in promoting entrepreneurship among students, Encourage mentorship by alumni for teams participating in TIDES program and promoting prizes and angel funding at the Institute for innovation and entrepreneurship",
            "Travel support for Students: INR 37.50 L",
            "Merit based Scholarship: INR 12.50 L"
        ]
    },
    {
        title: "Class gift by 1984 Batch (Rs. 62.92 L)",
        image: "/batch-1998.jpg",
        description: [
            "Established a corpus of Rs. 62.92 Lac by the Alumni of 1984-Batch to support the following schemes:",
            "Perpetual Support for Student's Technical Projects. (To fund interesting and big team projects on the campus, like building a racing car, robot, autonomous vehicle etc. which can compete at national/international competitions). - Rs.50 Lac.",
            "Perpetual Financial Aid for Students. (To help one or more needy students who are facing financial hardship because of their personal circumstances) - Rs. 12.92 Lac."
        ]
    },
    {
        title: "Class gift by 1983 Batch (Rs. 52.32 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1983 batch made a class gift of Rs. 52.32 Lac for",
            "Professional Development & Innovation Award sponsored by class of 1983",
            "The awards totalling Rs. 80,000/- (Rupees Eighty Thousand only) along with certificate will be given each year to innovative undergraduate engineering/architecture projects selected in the final semester of their course to facilitate IITR students’ professional development and promote innovation, selected IITR students will also be mentored in the final year of their undergraduate engineering /architecture",
        ]
    },
    {
        title: "1964 Batch (Including B.Arch 1966) (Rs. 25.06 L)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1964 batch (Including B.Arch.1966) donated Rs. 25.06 lacs during their Diamond Jubilee Reunion held in 2024 for the following purposes:",
            "Sujata Varshneya Gold Medal",
            "UOR64 BE & UOR66 B.Arch. Scholarship",
            "PD Agarwal Gold Medal in Mechanical Engineering"
        ]
    },
    {
        title: "Class gift by 1968 Batch (Rs. 21.24 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1968 batch made a class gift of Rs. 21.24 Lac during their Global Jubilee Reunion held in Nov 2018 to support the following schemes A and B for perpetuity and C as a one-time donation to Anushruti Academy for the Deaf (AAD):",
            "Seven Merit Cum Means Scholarships; each of Rs. 10000/- per annum (One for each dept. of Civil, Electrical, Mechanical & lndustrial, Electronics & Communication, Chemical, MetalIurgical & Material and Architecture &Planning): Rs. 17.50 Lac",
            "Overall Best Athlete (Female)Award of Rs. 100001 (who scores highest points: Stamp Cup Winner): Rs 2.50 Lac",
            "One-time donation to Anushruti Academy for the Deaf (AAD) (A Social initiative of IIT Roorkee, Uttarakhand): Rs 1.24 Lac",
        ]
    },
    {
        title: "Class gift by 1968 Batch (Rs. 15.97 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1968 batch donated Rs. 15.97 lacs during their Emerald Jubilee Reunion held in 2023 for the following purposes:",
            "1968 Batch Civil Engineering Scholarship",
            "1968 Batch Mechanical and Industrial Engineering Scholarship",
            "1968 Batch Electrical Engineering Scholarship",
            "Donation for Anushruti Academy for the Deaf"
        ]
    },
    {
        title: "Covid Relief Fund (Rs. 10.78 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of IITR and other donors have donated Rs. 10.78 lac for helping students of IITR who are facing adverse impacts and associated difficulties due to the Covid-19 outbreak."
        ]
    },
    {
        title: "Class gift by 1978 Batch (Rs. 7.95 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1978 batch donated Rs. 7.95 Lac during their Ruby Jubilee Reunion held in February 2018 to support the following schemes:",
            "Two Merit-cum-Means Scholarships.",
            "One time donation to Anushruti Academy for the Deaf.",
            "One time donation to Asmita for Women.",
        ]
    },
    {
        title: "Class gift by 1959 Batch (Rs. 6 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1959 batch donated Rs. 6 Lac during their Diamond Jubilee Reunion held in October 2019 to promote excellence in badminton with the following schemes:",
            "One running trophy each for Male and Female categories will be made and displayed in a suitable location.",
            "A cup, with the name engraved, besides a certificate, will be awarded to the winner as well as the runner up in Singles event for both ihe male and Female categories.",
            "An Honours Board will be affixed in the Badminton Hall carrying the names af all the four players in 2 above, session-wise.",
            "The tournaments will be conducted by the institute using their own internal resources while the donation shall be used exclusively for above purposes.",
        ]
    },
    {
        title: "Class gift by 1969 Batch (Rs. 5.11 L)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1969 batch donated Rs. 5.11 Lac during their Golden Jubilee Reunion held in November 2019 to support the following schemes:",
            "Two Merit-Cum-Means Scholarship."
        ]
    },
    // ... add more batch donors
];
