/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
     "./src/**/*.{js,jsx,ts,tsx}",
  ],
  // theme: {
  //   extend: {},
  // },
  theme: {
    extend: {
      fontFamily: {
        poltawski: ['"Poltawski Nowy"', 'serif'],
      },
    },
  },
  plugins: [],
}

