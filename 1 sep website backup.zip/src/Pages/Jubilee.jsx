import React from 'react'
import Events from '../Components/Events'

const Jubilee = () => {
  return (
    <Events />
  )
}

export default Jubilee