import React from 'react'

const ForFaculty = () => {
  return (
    <div>ForFaculty</div>
  )
}

export default ForFaculty