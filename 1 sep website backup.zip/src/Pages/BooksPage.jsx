import React from "react";

const books = [
  {
    title: "Fight Fraud with Machine Learning",
    author: "Ashish Ranjan Jha",
    batch: "B.E. - 2013",
    cover: "https://m.media-amazon.com/images/I/81PMyHKqssl.jpg",
    description:
      "Learn to build and deploy state-of-the-art fraud detection systems using machine learning techniques for financial and corporate fraud detection.",
  },
  {
    title: "Mastering PyTorch",
    author: "Ashish Ranjan Jha",
    batch: "B.E. - 2013",
    cover: "https://static.packt-cdn.com/products/9781801074308/cover/smaller",
    description:
      "Covers deep learning and neural network building using PyTorch. This book is suited for both beginners and practitioners in AI and ML.",
  },
  {
    title: "The Supervised Learning Workshop",
    author: "Ashish Ranjan Jha",
    batch: "B.E. - 2013",
    cover:
      "https://images-na.ssl-images-amazon.com/images/I/51F7GVGFtiL._SX397_BO1,204,203,200_.jpg",
    description:
      "A practical, hands-on book to learn supervised learning algorithms with real projects and guided exercises for learners.",
  },
  {
    title: "Deep Learning",
    author: "Ian Goodfellow, Yoshua Bengio, Aaron Courville",
    batch: "Reference",
    cover: "https://www.deeplearningbook.org/front_cover.jpg",
    description:
      "The most widely-recommended foundational textbook for deep learning, neural networks, and modern AI techniques.",
  },
  {
    title: "Pattern Recognition and Machine Learning",
    author: "Christopher M. Bishop",
    batch: "Reference",
    cover:
      "https://images-na.ssl-images-amazon.com/images/I/41Eyn0shdLL._SX379_BO1,204,203,200_.jpg",
    description:
      "A comprehensive book for theory and practical approaches to pattern recognition and machine learning.",
  },
  {
    title: "Programming Collective Intelligence",
    author: "Toby Segaran",
    batch: "Reference",
    cover:
      "https://images-na.ssl-images-amazon.com/images/I/51AUXIHRfPL._SX376_BO1,204,203,200_.jpg",
    description:
      "Practical guide for implementing machine learning algorithms and extracting patterns from your projects.",
  },
  {
    title: "Machine Learning in Action",
    author: "Peter Harrington",
    batch: "Reference",
    cover:
      "https://images-na.ssl-images-amazon.com/images/I/51uyH0dIwYL._SX379_BO1,204,203,200_.jpg",
    description:
      "Tutorial-style book teaching concepts and techniques in machine learning with algorithm and Python code walkthroughs.",
  },
];

const BooksPage = () => (
  <section className="bg-white min-h-screen py-10">
    <h2 className="text-6xl font-extrabold text-gray-400 text-center mb-10">
      Books By IITR Alumni
    </h2>
    <div className="max-w-6xl mx-auto px-6">
      {books.map((book, index) => (
        <div key={index} className="flex flex-col md:flex-row w-full mb-10">
          {/* Alternate Layout: Even index → text left, odd index → text right */}
          {index % 2 === 0 ? (
            <>
              {/* Left Side: Text */}
              <div className="flex-1 my-9 px-10 py-12 flex flex-col justify-center bg-slate-200">
                <h3 className="text-2xl md:text-3xl font-bold text-black mb-4">
                  {book.title}
                </h3>
                <p className="text-[17px] text-black/80 leading-relaxed">
                  {book.description}
                </p>
              </div>
              {/* Right Side: Book Card */}
              <div className="flex flex-col items-center justify-center bg-[#16335b] px-8 py-10 w-full md:w-80">
                <img
                  src={book.cover}
                  alt={book.title}
                  className="w-64 h-64 object-cover mb-6 shadow-lg"
                  style={{ background: "#fff" }}
                />
                <div className="text-center text-white text-[15px] space-y-1 mt-2">
                  <p className="font-semibold">{book.title}</p>
                  <p>Author Name: {book.author}</p>
                  <p>{book.batch}</p>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Left Side: Book Card */}
              <div className="flex flex-col items-center justify-center bg-[#16335b] px-8 py-10 w-full md:w-80">
                <img
                  src={book.cover}
                  alt={book.title}
                  className="w-64 h-64 object-cover mb-6 shadow-lg"
                  style={{ background: "#fff" }}
                />
                <div className="text-center text-white text-[15px] space-y-1 mt-2">
                  <p className="font-semibold">{book.title}</p>
                  <p>Author Name: {book.author}</p>
                  <p>{book.batch}</p>
                </div>
              </div>
              {/* Right Side: Text */}
              <div className="flex-1 my-9 px-10 py-12 flex flex-col justify-center bg-slate-200">
                <h3 className="text-2xl md:text-3xl font-bold text-black mb-4">
                  {book.title}
                </h3>
                <p className="text-[17px] text-black/80 leading-relaxed">
                  {book.description}
                </p>
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  </section>
);

export default BooksPage;
