export const individualDonors = [
    {
        title: "Mr. Ashok Soota",
        image: "/ashok-soota.jpg",
        description: [
            "Donated Rs. 20 crores (200 Million INR) to establish “Chair Professor” at IIT Roorkee.",
            "Three Faculty Fellowships",
            "Creation of a lab, and funding of joint research projects",
            "B.E. Electrical Engineering, 1963. Executive chairman, Happiest Minds Technologies Pvt. Ltd."
        ]
    },
    // ... add other individual donors here as needed
];

export const batchDonors = [
    {
        title: "1999 Batch (Including B.Arch 2000) (Pledge Rs. 5.05 Crore)",
        image: "/batch-1999.jpg",
        description: [
            "Alumni of 1999 batch Pledge Rs. 5.05 Crore (50.5 Million INR) during their Silver Jubilee Reunion held in 2024."
        ]
    },
    {
        title: "Class gift by 1998 Batch (Rs. 1.32 Crore)",
        image: "/batch-1998.jpg",
        description: [
            "Alumni of 1998 batch donated Rs. 1.32 Crore (13.2 Million INR) during their Silver Jubilee Reunion held in 2023 for the 16 scholarships."
        ]
    },
    // ... add more batch donors
];
